import torch
import numpy as np

def detect_outliers(model, data_dir, class_names):