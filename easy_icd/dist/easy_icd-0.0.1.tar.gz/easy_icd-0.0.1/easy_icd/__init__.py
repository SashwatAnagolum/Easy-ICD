name='easy_icd'

import scraping
import utils
import outlier_detection
import outlier_removal