# Easy-ICD: Automatic scraping and denoising of image classification datasets

#### CMPSC 445 Final Project
	
## References

* [A Simple Framework for Contrastive Learning of Visual Representations](https://arxiv.org/abs/2004.11362)
* [Supervised Contrastive Learning](https://arxiv.org/abs/2002.05709)
* [Supervised Contrastive Learning](https://arxiv.org/abs/2002.05709)
* [Supervised Contrastive Learning](https://arxiv.org/abs/2002.05709)
* [Supervised Contrastive Learning](https://arxiv.org/abs/2002.05709)
* [Supervised Contrastive Learning](https://arxiv.org/abs/2002.05709)
* [Supervised Contrastive Learning](https://arxiv.org/abs/2002.05709)
* [Supervised Contrastive Learning](https://arxiv.org/abs/2002.05709)