# Easy-ICD: Automatic scraping and denoising of image classification datasets
